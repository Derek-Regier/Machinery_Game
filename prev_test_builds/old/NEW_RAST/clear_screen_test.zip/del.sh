#!/bin/bash
rm -- *.O*
rm tst_rast.prg
rm -- *.o*