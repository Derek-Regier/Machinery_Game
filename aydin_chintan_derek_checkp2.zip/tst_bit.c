/*
 * tstbit.c - Visual test for bitmaps
 *
 * Screen layout reminder: 640 wide x 400 tall, top-left = (0,0).
 *
 * Authors: Aydin Salonius, Chintan Thakor, Derek Regier
 * Course: COMP 2659, Winter 2026
 */

#include <osbind.h>
#include "raster.h"
#include "bitmaps.h"

 /* 
 wait - halts until any key is pressed.
 */
static void wait(void)
{
    Cnecin();
}

int main()
{
    void *base = Physbase();

    int r, w;


    /* ----------------------------------------------------------------
     * STAGE 1: plot_bitmaps
     * Plots corresponding bitmaps:
     * - health_bar
     * - player
     * - enemy
     * - hp_pot
     * - boss 
     * in that order upon key presses.
     * ---------------------------------------------------------------- */

    clear_screen(base);
    wait();
    
    pbm32(base, 4, 4, health_bar_bitmap, 12);
    wait();
    pbm32(base, 4, 36, health_bar_bitmap, 12);
    wait();
    pbm32(base, 300, 256, player_bitmap, 64);
    wait();
    pbm32(base, 300, 500, enemy_bitmap, 64);
    wait();
    pbm16(base, 300, 200, hp_pot_bitmap, 16);
    wait();
    for (r = 0; r < 128; r++){
        for (w = 0; w < 4; w++){
            pbm32(base, 100 + r, 200 + (w * 32), &boss_bitmap[r][w], 1);}
        }
    wait();
    clear_screen(base);
    
    
    wait();
    return 0;
    

}

    
